package LagacyVM;

public class VandingMachineTest {
    public static void main(String[] args) {


    }
}
