package ch06.quiz;

import java.util.Arrays;

public class SelectSort1 {
    public static void main(String[] args) {
        int[] selectSort = {9,6,7,3,5};
        int temp;

        for(int i = 1; i < selectSort.length; i++){
            for(int k=0; k <= i-1; k++){
                if(selectSort[i]<selectSort[k]){
                    temp = selectSort[i];
                    selectSort[i] = selectSort[k];
                    selectSort[k] = temp;
                }
            }
            System.out.println(i + "회전 = " + Arrays.toString(selectSort));
        }

    }
}