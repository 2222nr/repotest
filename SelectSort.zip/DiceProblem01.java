package ch06.quiz;

import java.util.Arrays;
import java.util.Random;

public class DiceProblem01 {
    public static void main(String[] args) {
        Random random = new Random();
        int[] dice01 = new int[6];
        int currNum;
        int count = 0;
        int index = 0;

        for (int i = 1; i <= 30000; i++) {
            currNum = random.nextInt(6) + 1;
            switch (currNum) {
                case 1:
                    dice01[0] += 1;
                    break;
                case 2:
                    dice01[1] += 1;
                    break;
                case 3:
                    dice01[2] += 1;
                    break;
                case 4:
                    dice01[3] += 1;
                    break;
                case 5:
                    dice01[4] += 1;
                    break;
                case 6:
                    dice01[5] += 1;
                    break;
            }
        }

        // System.out.println(Arrays.toString(dice01));
        for (index = 0; index < dice01.length; index++) {
            double temp = (double) dice01[index]/30000;
            System.out.printf("%d : %d (%.6f)\n", index+1, dice01[index], temp);
            count += dice01[index];
        }
        System.out.println("총 던진 횟수 : " + count);
    }
}
