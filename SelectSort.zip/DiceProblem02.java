package ch06.quiz;

import java.util.Arrays;
import java.util.Random;

public class DiceProblem02 {
    public static void main(String[] args) {
        Random random = new Random();
        final int count = 36000;
        int[] dice02 = new int[11];
        int currNum = 0;
        int totalCount = 0;

        for (int i = 1; i <= count; i++) {
            currNum = random.nextInt(11) + 2;
            dice02[currNum-2] += 1;
            }

        //System.out.println(Arrays.toString(dice02));
        for (int j = 0; j < dice02.length; j++) {
            double temp = (double) dice02[j]/36000;
            System.out.printf("%d : %d (%.6f)\n", j+2, dice02[j], temp);
            totalCount += dice02[j];
        }
        System.out.println("총 던진 횟수 : " + totalCount);

    }
}
