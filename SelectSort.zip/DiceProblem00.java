package ch06.quiz;

import java.util.Arrays;
import java.util.Random;

public class DiceProblem00 {
    public static void main(String[] args) {
        Random random = new Random();
        int[] dice01 = new int[6];
        int currNum;
        int count = 0;
        //int index = 0;

        for (int i = 1; i <= 30000; i++) {
            currNum = random.nextInt(6) + 1;
            for(int k = 1; k<=6; k++) {         //diceNum[currNum-1] += 1;
                if(currNum == k){
                    dice01[k-1] += 1;
                }
            }
        }
            //System.out.println(Arrays.toString(dice01));
        for (int j = 0; j < dice01.length; j++) {
            double temp = (double) dice01[j]/30000;
            System.out.printf("%d : %d (%.6f)\n", j+1, dice01[j], temp);
            count += dice01[j];
        }
        System.out.println("총 던진 횟수 : " + count);
    }
}
