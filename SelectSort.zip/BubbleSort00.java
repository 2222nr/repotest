package ch06.quiz;

import java.util.Arrays;

public class BubbleSort00 {
    public static void main(String[] args) {
        int[] numList = {7, 4, 5, 1, 3};
        int temp;

        for (int i = 1; i < numList.length; i++) {
            boolean flag = true;
            for (int k = 0; k <numList.length-1-i; k++) {
                if (numList[k] > numList[k+1]) {
                    temp = numList[k];
                    numList[k] = numList[k+1];
                    numList[k+1] = temp;
                    flag = false;
                }
            }
            if(flag==true) break;

            System.out.printf(i + "회전 = " );
            for(int data : numList){
                System.out.printf(data + " ");
            }
            System.out.println(" ");
        }

    }
}
