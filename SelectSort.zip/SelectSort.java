package ch06.quiz;

import java.util.Arrays;

public class SelectSort {
    public static void main(String[] args) {
        int[] selectSort = {9,6,7,3,5};
        int temp;
        int index;  //


        for(int i=0; i<=selectSort.length-1; i++){
            index = i;
            for(int k=i+1; k<selectSort.length; k++){
                if(selectSort[index] > selectSort[k])
                    index = k;
            }
            temp = selectSort[i];
            selectSort[i] = selectSort[index];
            selectSort[index] = temp;

            if(i < selectSort.length-1){
            System.out.println(i+1 + "회전 = " + Arrays.toString(selectSort));
            }

        }

    }
}
