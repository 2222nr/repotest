package ch06.quiz;

import java.util.Arrays;

public class BubbleSort1 {
    public static void main(String[] args) {
        int[] numList = {7,4,5,1,3};
        int temp;

        for(int i = 0; i <= numList.length-1; i++){
            for(int k=0; k < numList.length; k++){
                if(numList[i]<numList[k]){
                    temp = numList[i];
                    numList[i] = numList[k];
                    numList[k] = temp;
                }
            }
            System.out.println(i + "회전 = " + Arrays.toString(numList));
        }

    }
}
