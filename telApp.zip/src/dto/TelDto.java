package dto;

public class TelDto {
    private int id;
    private String name;
    private int age;
    private String addr;
    private String telNum;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public String getAddr() {
        return addr;
    }

    public void setAddr(String addr) {
        this.addr = addr;
    }

    public String getTelNum() {
        return telNum;
    }

    public void setTelNum(String telNum) {
        this.telNum = telNum;
    }
    public TelDto(String name, int age, String addr, String telNum) {
        this.name = name;
        this.age = age;
        this.addr = addr;
        this.telNum = telNum;
    }
    public TelDto(int id, String name, int age, String addr, String telNum) {
        this.id = id;
        this.name = name;
        this.age = age;
        this.addr = addr;
        this.telNum = telNum;
    }
    public TelDto(){}
    public static TelDto of(String name, int age, String address, String telNum){
        return new TelDto(name, age, address, telNum);
    }
    public static TelDto allOf(int id,String name, int age, String address, String telNum){
        return new TelDto(id, name, age, address, telNum);
    }


    @Override
    public String toString() {
        String str;
        str = String.format("  %d \t%s \t %d \t" +
                " %s \t %s \t ", id, name, age, addr, telNum);
        return str;
    }
}
