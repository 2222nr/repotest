import db.DBConn;
import dto.TelDto;
import exception.MyException;
import service.TelBookService;
import view.UserView;

import java.sql.Connection;
import java.util.Scanner;

public class TelAppMain {
    public static void main(String[] args) {
//        Connection conn = DBConn.getConnection();
        TelBookService service = new TelBookService();
        UserView userView = new UserView();
        Scanner sc = new Scanner(System.in);
        int ch = 0;
        while(true){
            do{
                System.out.println("1.입력 2.수정 3.삭제 4.전체출력 5.아이디검색 6.종료");
                System.out.println("==================================================");
                ch = sc.nextInt();
            } while(ch < 0 || ch > 6);
            switch (ch){
                case 1:
                    try {
                        userView.insert();
                    } catch (Exception e) {
                        throw new RuntimeException(e);
                    }
                    break;
                case 2:
                    System.out.println("2.수정");
                    userView.update();
                    break;
                case 3:
                    System.out.println("3.삭제");
                    userView.delete();
                    break;
                case 4:
                    System.out.println("4.전체출력");
                    userView.searchAll();
                    break;
                case 5:
                    System.out.println("5.아이디검색");
                    userView.searchOne();
                    break;
                case 6:
                    DBConn.close();
                    System.exit(0);
            }
        }
    }
}
