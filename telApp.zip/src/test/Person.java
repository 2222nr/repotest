package test;

public record Person(String name, int age) {

}
