package view;

import dto.TelDto;
import exception.InputValidation;
import exception.MyException;
import service.TelBookService;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class UserView {
    Scanner sc = new Scanner(System.in);
    InputValidation validation = new InputValidation();
    TelBookService service = new TelBookService();

    public void searchAll() {
        List<TelDto> dtoList = new ArrayList<>();
        dtoList = service.getListAll();
        if (dtoList.isEmpty()) {
            System.out.println("데이터가 존재하지 않습니다.");
            return;
        } else {
            PrintTitle.line();
            PrintTitle.title();
            for (TelDto dto : dtoList) {
                System.out.println(dto);
            }
            PrintTitle.line();
        }
    }
    public void insert() throws Exception {
        String name = null;
        int age = 0;
        String address = null;
        String telNum = null;
        System.out.println("========= 전화번호 등록 =========");
        boolean checkName = true;
        do {
            try {
                System.out.print("이름 : ");
                name = sc.next();
                validation.nameCheck(name);
                checkName = false;
                System.out.println("한글 이름입니다.");
            } catch (MyException e) {
                System.out.println(e.toString());
            }
        } while (checkName == true);

        boolean checkAge = true;
        do {
            try {
                System.out.print("나이 : ");
                age = sc.nextInt();
                validation.ageCheck(age);
                checkAge = false;
                System.out.println("정상입니다.");
            } catch (MyException e) {
                System.out.println(e.toString());
            }
        } while (checkAge == true);

        System.out.print("주소 : ");
        address = sc.next();

        boolean checkTelNum = true;
        do {
            try {
                System.out.print("전화번호 : ");
                telNum = sc.next();
                validation.phoneCheck(telNum);
                checkTelNum = false;
                System.out.println("정상입니다.");
            } catch (MyException e) {
                System.out.println(e.toString());
            }
        } while (checkTelNum == true);

        // 받은 데이터를 데이터베이스에 저장하는 메서드를 호출


        int result = service.insertData(TelDto.of(name, age, address, telNum));
        if (result != 0) {
            System.out.println();
            System.out.println("####### 성공적으로 입력되었습니다. #######");
            System.out.println();
        }
    }
    public void delete() {
        int id;
        System.out.print("삭제할 전화번호부의 ID 입력 : ");
        id = sc.nextInt();
        int result = service.deleteData(id);
        if (result != 0) {
            System.out.println("ID : " + id + "의 자료가 삭제되었습니다.");
        } else {
            System.out.println("자료 삭제에 실패하였습니다.");
        }
    }
    public void searchOne(){
        TelDto dto = null;
        System.out.print("검색할 ID : ");
        int id = sc.nextInt();
        dto = service.searchOne(id);
        if(dto == null){
            System.out.println("검색한 데이터가 존재하지 않습니다.");
        } else {
            PrintTitle.line();
            PrintTitle.title();
            System.out.println(dto.toString());
            PrintTitle.line();
        }
    }
    public void update(){
        int id;
        String name = null;
        int age = 0;
        String address = null;
        String telNum = null;
        //TelDto dto = null;
        TelDto oldDto = null;
        String yesOrNo;
        System.out.print("수정할 ID : ");
        id = sc.nextInt();
        oldDto = service.searchOne(id);
        if(oldDto == null){
            System.out.println("해당하는 ID가 없습니다.");
        } else { id = oldDto.getId(); }

        System.out.println("기존 이름 : " + oldDto.getName());
        do{
            System.out.print("수정하시겠습니까?(Y/N)");
            yesOrNo = sc.next();
        } while(!(yesOrNo.toUpperCase().equals("Y") ||  yesOrNo.toUpperCase().equals("N")));

        if(yesOrNo.toUpperCase().equals("Y")) {
            boolean checkName = true;
            do {
                try {
                    System.out.print("이름 : ");
                    name = sc.next();
                    validation.nameCheck(name);
                    checkName = false;
                    System.out.println("한글 이름입니다.");
                } catch (MyException e) {
                    System.out.println(e.toString());
                }
            } while (checkName == true);
        } else {
            name = oldDto.getName();}

            System.out.println("기존 나이 : " + oldDto.getAge());
            do {
                System.out.print("수정하시겠습니까?(Y/N)");
                yesOrNo = sc.next();
            } while (! (yesOrNo.toUpperCase().equals("Y") || yesOrNo.toUpperCase().equals("N")));

            if (yesOrNo.toUpperCase().equals("Y")) {
                boolean checkAge = true;
                do {
                    try {
                        System.out.print("나이 : ");
                        age = sc.nextInt();
                        validation.ageCheck(age);
                        checkAge = false;
                        System.out.println("정상입니다.");
                    } catch (MyException e) {
                        System.out.println(e.toString());
                    }
                } while (checkAge == true);
            } else {
                age = oldDto.getAge();
            }

            System.out.println("기존 주소 : " + oldDto.getAddr());
            do {
                System.out.print("수정하시겠습니까?(Y/N)");
                yesOrNo = sc.next();
            } while (! (yesOrNo.toUpperCase().equals("Y") || yesOrNo.toUpperCase().equals("N")));
            if (yesOrNo.toUpperCase().equals("Y")) {
                System.out.print("주소 : ");
                address = sc.next();
            } else {
                address = oldDto.getAddr();
            }

            System.out.println("기존 전화번호 : " + oldDto.getTelNum());
            do {
                System.out.print("수정하시겠습니까?(Y/N)");
                yesOrNo = sc.next();
            } while (!(yesOrNo.toUpperCase().equals("Y") || yesOrNo.toUpperCase().equals("N")));
            if (yesOrNo.toUpperCase().equals("Y")) {
                boolean checkTelNum = true;
                do {
                    try {
                        System.out.print("전화번호 : ");
                        telNum = sc.next();
                        validation.phoneCheck(telNum);
                        checkTelNum = false;
                        System.out.println("정상입니다.");
                    } catch (MyException e) {
                        System.out.println(e.toString());
                    }
                } while (checkTelNum == true);
            } else {
                telNum = oldDto.getTelNum();
            }

            // 받은 데이터를 데이터베이스에 저장하는 메서드를 호출

            int result = service.updateData(TelDto.allOf(id,name, age, address, telNum));
            if (result != 0) {
                System.out.println("데이터를 성공적으로 수정하였습니다.");
                System.out.println();
            } else {
                System.out.println("데이터 수정에 실패하였습니다.");

            }
        }
    }
