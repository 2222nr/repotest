import java.util.Arrays;
import java.util.Random;
import java.util.Scanner;

public class BaseBallGame {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        Random random = new Random();
        int[] rightAnswer = new int[3];
        String[] str = new String[3];
        int[] userAnswer = new int[3];
        int strike = 0;
        int ball = 0;
        int count = 1;

        for (int x = 0; x < rightAnswer.length; x++) {
            int randomNum = random.nextInt(9);
            rightAnswer[x] = randomNum;
            for (int y = 0; x > y; y++) {
                if (rightAnswer[x] == rightAnswer[y]) {
                    x--;
                    break;
                }
            }
        }
                //System.out.println(Arrays.toString(rightAnswer));
                for (count = 1; count <= 10; count++) {
                    System.out.print(count + "번째. 서로 다른 세 자리 정수를 입력해 주세요. : ");
                    str = sc.next().split("");
                    //System.out.println(Arrays.toString(rightAnswer));
                    //System.out.println(Arrays.toString(str));
                    for (int i = 0; i < userAnswer.length; i++) {
                        userAnswer[i] = Integer.parseInt(str[i]);
                    }
                    for (int j = 0; j < rightAnswer.length; j++) {
                        for (int k = 0; k < userAnswer.length; k++) {
                            if (rightAnswer[j] == userAnswer[k]) {
                                if (j == k) {
                                    strike += 1;
                                } else {
                                    ball += 1;
                                }
                            }
                        }
                    }
                    if (strike < 3) {
                        System.out.print(strike + "Strike " + ball + "Ball");
                        System.out.println(" ");
                        strike = 0;
                        ball = 0;
                    } else if (strike == 3) {
                        System.out.println("정답입니다.");
                        break;
                    }
                    if (count == 10) {
                        System.out.println("실패입니다!! 정답은 " + Arrays.toString(rightAnswer) + "입니다.");
                    }
                }
        }
    }