package LagacyVM;

import java.util.Scanner;

public class VendingMachine {
    static Scanner sc = new Scanner(System.in);
    static final int Max = 5;
    static String[] product = new String[Max];
    static int[] price = new int[Max];
    static int[] stock = new int[Max];
    static int currMoney = 0;
    static int selectNum = 0;
    static int profit = 0;  //관리자 총 수입 계산용
    static boolean first = true;


    public static void initialize() {
        product[0] = "콜라";
        price[0] = 500;
        stock[0] = 3;
        product[1] = "사이다";
        price[1] = 700;
        stock[1] = 3;
        product[2] = "커피";
        price[2] = 1500;
        stock[2] = 3;
        //int step = 1;
    }

    static void user() {
        // int step = 1;
        while (true) {
            System.out.println("=========================================================");
            System.out.println("자판기입니다. (번호:상품(가격)-재고)");
            for (int i = 0; i < product.length; i++) {
                if (product[i] != null) {
                    System.out.print((i + 1) + ":" + product[i] + "(" + price[i] + "W)-" + stock[i] + "개 ");
                }
            }
            System.out.println(" ");
            System.out.println("=========================================================");
            // 처음에만 돈을 입력받기
            if (first == true || currMoney == 0) {
                System.out.print("돈을 넣어주세요 : ");
                int inputMoney = sc.nextInt();
                if (inputMoney < 10) {
                    System.out.println("입력 오류입니다."); break; }
                if (inputMoney == 1004) {
                    System.out.println("잔액 " + currMoney + "원이 반환됩니다.");
                    currMoney = 0;
                    admin();
                }
                if(inputMoney != 1004) {
                    currMoney = currMoney + inputMoney;
                    System.out.println("현재 잔액은 " + currMoney + "입니다.");
                    first = false;}

            }
            //처음이 아닌 경우 메뉴를 선택
            if (first == false || currMoney != 0) {
                System.out.print("메뉴 입력 : ");
                selectNum = sc.nextInt();
                for (int k = 0; k < product.length; k++) {
                    if (selectNum == k + 1 && currMoney >= price[selectNum - 1] && stock[selectNum-1] != 0) {
                        System.out.println(product[k] + "가 나왔습니다.");
                        stock[k] -= 1;
                        currMoney -= price[k];
                        profit = profit + price[k];
                        System.out.println("현재 잔액은 " + currMoney + "입니다.");
                    } else if (selectNum == k + 1 && currMoney < price[selectNum - 1] && currMoney != 0) {
                        System.out.println("잔액이 부족합니다.");
                        System.out.println("현재 잔액은 " + currMoney + "입니다.");
                    } else if (selectNum == k + 1 && stock[selectNum-1] == 0) {
                        System.out.println("품절입니다.");
                    }
                    else if (product[selectNum-1] == null) {
                        break;}
                }
            }
            if (currMoney != 0 && first == false) {
                System.out.println("1:계속구매하기  2:금액추가하기  3.잔돈반환하기");
                System.out.print("번호를 입력하세요 : ");
                int num = sc.nextInt();
                if (num == 1) {
                    // step = 1;
                    first = false;
                } else if (num == 2) {
                   // step = 1;
                    first = true;
                } else if (num == 3) {
                    System.out.println("거스름 돈 " + currMoney + "원이 반환됩니다.");
                    System.out.println("감사합니다! 다음에 또 이용해주세요");
                    System.out.println(" ");
                    currMoney = 0;
                    //step = 1;
                    first = true;
                }
            }
        }
    }

    static void admin() {
        int adminNum = 0;
        do {
            System.out.println("=========================================================");
            System.out.println("관리자 페이지 입니다.");
            System.out.println("1:메뉴변경 2:가격변경 3:재고추가 4:메뉴추가 5.수익확인(종료는 -1)");
            System.out.print("번호를 입력하세요:");
            adminNum = sc.nextInt();
            switch (adminNum) {
                case 1:
                    System.out.print("변경하실 메뉴의 번호를 입력하세요 : ");
                    int i = sc.nextInt();
                    if(product[i-1] == null) {
                        System.out.println("메뉴 추가가 필요합니다."); break;}
                    System.out.print(product[i-1] + "를(을) 무엇으로 바꾸시겠습니까? : ");
                    product[i-1] = sc.next();
                    System.out.print(product[i-1] + "의 가격은 얼마입니까? : ");
                    price[i-1] = sc.nextInt();
                    System.out.print(product[i-1] + "의 재고를 몇 개 등록하시겠습니까? : ");
                    stock[i-1] = sc.nextInt();
                    System.out.println("메뉴 변경이 완료되었습니다! : ");
                    break;
                case 2:
                    System.out.print("가격을 변경하실 메뉴의 번호를 입력하세요 : ");
                    i = sc.nextInt();
                    System.out.print(product[i - 1] + "의 가격을 얼마로 바꾸시겠습니까? : ");
                    price[i - 1] = sc.nextInt();
                    System.out.println("가격 변경이 완료되었습니다! : ");
                    break;
                case 3:
                    System.out.print("재고를 추가하실 메뉴의 번호를 입력하세요 : ");
                    i = sc.nextInt();
                    System.out.print(product[i - 1] + "를(을) 몇 개 추가하시겠습니까? : ");
                    stock[i - 1] = sc.nextInt();
                    System.out.println("재고 추가가 완료되었습니다! : ");
                    break;
                case 4:
                    int k = -1;
                    for (i = 0; i < product.length; i++) {
                        if (product[i] == null) {
                            k = i;  //3
                            break;
                        }
                    }
                    if (k > 0) {
                        System.out.print("추가하실 메뉴의 가격을 입력하세요 : ");
                        price[k] = sc.nextInt();
                        System.out.print("추가하실 메뉴의 이름을 입력하세요 : ");
                        product[k] = sc.next();
                        System.out.print(product[k] + "의 재고는 몇 개 입니까? : ");
                        stock[k] = sc.nextInt();
                        System.out.println("메뉴 추가가 완료되었습니다!");
                        break;
                    } else if (k == -1) {
                        System.out.println("더이상 메뉴가 들어갈 자리가 없습니다.");
                        break;
                    }
                case 5:
                    System.out.println("현재까지의 수익은 " + profit + "원 입니다.");
                    break;
                case -1 :
                    return;
            }
        } while (adminNum >= 0);
    }
    public static void main(String[] args) {
        initialize();
        user();
        return;

    }
}
