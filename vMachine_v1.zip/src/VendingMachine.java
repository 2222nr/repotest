import init.InitClass;
import view.AdminView;
import view.UserView;

import java.util.Scanner;

public class VendingMachine {

    public static void main(String[] args) {
        UserView userView = new UserView();
        AdminView adminView = new AdminView();
//        InitClass initClass
//                = new InitClass();
        InitClass.initialize();
        userView.userView();

    }
}