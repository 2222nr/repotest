package view;

import init.InitClass;
import service.AdminService;

import java.util.Arrays;
import java.util.Scanner;

public class AdminView {
    Scanner sc = new Scanner(System.in);
    AdminService adminService = new AdminService();
    UserView userView = new UserView();

    public static int adminNum = 0;

    public void adminView() {
            while (true){
            System.out.println("=========================================================");
            System.out.println("관리자 페이지 입니다.");
            System.out.println("1:메뉴변경 2:가격변경 3:재고추가 4:메뉴추가 5.수익확인 (종료는 -1)");
            System.out.print("번호를 입력하세요 : ");
            adminNum = sc.nextInt();
            switch (adminNum) {
                case 1:
                    adminService.updateMenu();
                    break;
                case 2:
                    adminService.updatePrice();
                    break;
                case 3:
                    adminService.updateStock();
                    break;
                case 4:
                    adminService.addMenu();
                    break;
                case 5:
                    adminService.confirmProfit();
                    break;
                case -1:
                    userView.userView();
            }
            }

    }
}

