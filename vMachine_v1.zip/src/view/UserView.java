package view;

import init.InitClass;
import service.UserService;

import java.util.Scanner;

public class UserView {
    Scanner sc = new Scanner(System.in);
     public void userView() {
         UserService userService = new UserService();
         AdminView adminView = new AdminView();
         //InitClass initClass = new InitClass();
         //initClass.initialize();

         //while (true) {
             InitClass.line();
             System.out.println("자판기입니다. (번호:상품(가격)-재고)");
             for (int i = 0; i < InitClass.product.length; i++) {
                 if (InitClass.product[i] != null) {
                     System.out.print((i + 1) + ":" + InitClass.product[i] + "(" + InitClass.price[i] + "W)-" + InitClass.stock[i] + "개 ");
                 }
             }
             System.out.println(" ");
             InitClass.line();
             // 처음에만 돈을 입력받기
             if (InitClass.currMoney == 0){
                 userService.addMoney();}

             if (InitClass.first == false && InitClass.currMoney != 0) {
                 userService.outProduct();
                 InitClass.first = true; }

                 int num = 0;
                 while (InitClass.first == true && InitClass.currMoney != 0) {
                     InitClass.line();
                     System.out.println("1:계속구매하기  2:금액추가하기  3.잔돈반환하기");
                     System.out.print("번호를 입력하세요 : ");
                     num = sc.nextInt();
                     if (num>3) {
                         System.out.println("잘못입력하셨습니다.");
                         num = 0;
                         continue;}
                     if (num == 1) {
                         userView();
                         InitClass.first = false;
                     } else if (num == 2) {
                         userService.addMoney();
                         InitClass.first = false;
                     } else if (num == 3) {
                         userService.returnMoney();
                         InitClass.first = false;
                     } else {
                         userService.returnMoney();
                     }
             }
         }

            //처음이 아닌 경우 메뉴를 선택

        }

