package init;

import java.util.Scanner;

public class InitClass {
    static Scanner sc = new Scanner(System.in);
    public static final int Max = 5;
    public static String[] product = new String[Max];
    //public static String[] product = new String[] {"콜라", "사이다", "커피", null, null};
    public static int[] price = new int[Max];
    // public static int[] price = new int[] {500, 700, 1500, 0, 0};
    public static int[] stock = new int[Max];
    // public static int[] stock = new int[] {3, 3, 3, 0, 0};
    public static int currMoney = 0;
    public static int selectNum = 0;
    public static int profit = 0;  //관리자 총 수입 계산용
    public static boolean first = true;

    public static int menuNum = 0;

    public static void initialize() {
        product[0] = "콜라";
        price[0] = 500;
        stock[0] = 3;
        product[1] = "사이다";
        price[1] = 700;
        stock[1] = 3;
        product[2] = "커피";
        price[2] = 1500;
        stock[2] = 3;

   }

    public static void line(){
        System.out.println("=========================================================");
    }
}
