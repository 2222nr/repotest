package service;

import init.InitClass;
import view.AdminView;
import view.UserView;

import java.util.Scanner;

public class UserService {
    AdminView adminView = new AdminView();
    UserView userView = new UserView();
    Scanner sc = new Scanner(System.in);


    public void outProduct() {
        System.out.print("메뉴 입력 : ");
        InitClass.selectNum = sc.nextInt();
        if (InitClass.selectNum>InitClass.product.length) {
            System.out.println("잘못입력하셨습니다.");
        }
        for (int k = 0; k < InitClass.product.length; k++) {
            if (InitClass.selectNum == k + 1 && InitClass.currMoney >= InitClass.price[InitClass.selectNum - 1] && InitClass.stock[InitClass.selectNum - 1] != 0) {
                System.out.println(InitClass.product[k] + "가 나왔습니다.");
                InitClass.stock[k] -= 1;
                InitClass.currMoney -= InitClass.price[k];
                InitClass.profit = InitClass.profit + InitClass.price[k];
                System.out.println("현재 잔액은 " + InitClass.currMoney + "입니다.");
                InitClass.first = true;
            } else if (InitClass.selectNum == k + 1 && InitClass.currMoney < InitClass.price[InitClass.selectNum - 1] ) {
                System.out.println("잔액이 부족합니다.");
                System.out.println("현재 잔액은 " + InitClass.currMoney + "입니다.");
                InitClass.first = true;
            } else if (InitClass.selectNum == k + 1 && InitClass.stock[InitClass.selectNum - 1] == 0) {
                System.out.println("품절입니다.");
                InitClass.first = true;
            } else if (InitClass.product[InitClass.selectNum - 1] == null) {
                System.out.println("없는 제품 번호 입니다.");
                InitClass.first = true;
            }
        }
        if (InitClass.currMoney == 0) {
            userView.userView();
        }
    }
    public void addMoney() {
        if (InitClass.first == true || InitClass.currMoney == 0) {
            System.out.print("돈을 넣어주세요 : ");
            int inputMoney = sc.nextInt();

            if (inputMoney == 1004) {
                adminView.adminView();
                InitClass.first = false;
            } else {
                InitClass.currMoney = InitClass.currMoney + inputMoney;
                System.out.println("현재 잔액은 " + InitClass.currMoney + "입니다.");
                InitClass.first = false;
                outProduct();
            }
        }
    }
    public void returnMoney() {
        System.out.println("거스름 돈 " + InitClass.currMoney + "원이 반환됩니다.");
        System.out.println("감사합니다! 다음에 또 이용해주세요");
        System.out.println(" ");
        InitClass.currMoney = 0;
        InitClass.first = true;
    }
    public void callAdmin() {
        adminView.adminView();

    }

}