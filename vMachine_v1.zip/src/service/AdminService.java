package service;

import init.InitClass;
import view.AdminView;

import java.util.Arrays;
import java.util.Scanner;

public class AdminService {
    Scanner sc = new Scanner(System.in);
    //InitClass initClass = new InitClass();
    public void updateMenu() {
        System.out.print("변경하실 메뉴의 번호를 입력하세요 : ");
        int i = sc.nextInt();
        System.out.print(InitClass.product[i - 1] + "를(을) 무엇으로 바꾸시겠습니까? : ");
        String name = sc.next();
        System.out.print(name + "의 가격은 얼마입니까? : ");
        int p = sc.nextInt();
        System.out.print(name + "의 재고를 몇 개 등록하시겠습니까? : ");
        int s = sc.nextInt();
        System.out.println("메뉴 변경이 완료되었습니다!");
        InitClass.product[i - 1] = name;
        InitClass.price[i - 1] = p;
        InitClass.stock[i - 1] = s;

        AdminView.adminNum = 0;

        if (i > InitClass.product.length) {
            System.out.println("잘못입력하셨습니다.");}
        if (InitClass.product[i - 1] == null) {
                System.out.println("해당 번호는 비어있습니다.");
        }
    }
        public void updatePrice () {
            System.out.print("가격을 변경하실 메뉴의 번호를 입력하세요 : ");
            InitClass.menuNum = sc.nextInt();
            if (InitClass.menuNum > InitClass.product.length) {
                System.out.println("잘못입력하셨습니다.");
            }
            if (InitClass.product[InitClass.menuNum - 1] == null) {
                System.out.println("해당 번호는 비어있습니다.");
            }
            System.out.print(InitClass.product[InitClass.menuNum - 1] + "의 가격을 얼마로 바꾸시겠습니까? : ");
            int temp = sc.nextInt();
            InitClass.price[InitClass.menuNum - 1] = temp;
            System.out.println("가격 변경이 완료되었습니다!");
            AdminView.adminNum = 0;

        }

        public void updateStock () {
            System.out.print("재고를 추가하실 메뉴의 번호를 입력하세요 : ");
            InitClass.menuNum = sc.nextInt();
            System.out.print(InitClass.product[InitClass.menuNum - 1] + "를(을) 몇 개 추가하시겠습니까? : ");
            int temp = sc.nextInt();
            InitClass.stock[InitClass.menuNum - 1] += temp;
            System.out.println("재고 추가가 완료되었습니다!");
            AdminView.adminNum = 0;

            if (InitClass.menuNum>InitClass.product.length) {
                System.out.println("잘못입력하셨습니다.");
            }
            if(InitClass.product[InitClass.menuNum-1] == null) {
                System.out.println("해당 번호는 비어있습니다.");}
    }
        public void addMenu () {
            int k = -1;
            if (InitClass.menuNum>InitClass.product.length) {
                System.out.println("잘못입력하셨습니다.");
            }
            for (InitClass.menuNum = 0; InitClass.menuNum < InitClass.product.length; InitClass.menuNum++) {
                if (InitClass.product[InitClass.menuNum] == null) {
                    k = InitClass.menuNum;  //3
                    break;
                }
            }
            if (k > 0) {
                System.out.print("추가하실 메뉴의 이름을 입력하세요 : ");
                InitClass.product[k] = sc.next();
                System.out.print("추가하실 메뉴의 가격을 입력하세요 : ");
                InitClass.price[k] = sc.nextInt();
                System.out.print(InitClass.product[k] + "의 재고는 몇 개 입니까? : ");
                InitClass.stock[k] = sc.nextInt();
                System.out.println("메뉴 추가가 완료되었습니다!");
                AdminView.adminNum = 0;
            } else if (k == -1) {
                System.out.println("더이상 메뉴가 들어갈 자리가 없습니다.");
                AdminView.adminNum = 0;
            }
        }
        public void confirmProfit () {
            System.out.println("현재까지의 수익은 " + InitClass.profit + "원 입니다.");
        }

}
