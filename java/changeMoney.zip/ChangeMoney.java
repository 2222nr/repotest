package changeMoney;

import java.util.Scanner;
import java.text.DecimalFormat;

public class ChangeMoney {
    static void exchangeMoney(int currentMoney) {
        int[] money = {50000, 10000, 5000, 1000, 500, 100};
        DecimalFormat df = new DecimalFormat("###,###");
        for (int i = 0; i < money.length; i++) {
            String strMoney = df.format(money[i]);
            int changeMoney = currentMoney / money[i];
            System.out.printf("%6s원권 : %3d장\n", strMoney, changeMoney);
            currentMoney = currentMoney % money[i];
        }
    }
        public static void main (String[] args){

            Scanner sc = new Scanner(System.in);
            String yesOrNo = "Y";
            do {
                System.out.println("---------------------------------");
                System.out.print("변환할 금액을 입력하세요 : ");
                int currentMoney = sc.nextInt();
                exchangeMoney(currentMoney);
                System.out.print("계속하시겠습니까?(Y/N) : ");
                yesOrNo = sc.next();
                yesOrNo = yesOrNo.toUpperCase();
            } while (yesOrNo.equals("Y"));

            sc.close();
        }
    }
