package Vm01;

public class VenMachine00 {
    static String[] product = {"콜라", "사이다", "커피"};
    static int select;


    void serve(int select1){
        select = select1;
            if(select == 1){
                System.out.println("====================================");
                System.out.println("콜라를 선택했습니다.");
            } else if(select == 2){
                System.out.println("====================================");
                System.out.println("사이다를 선택했습니다.");
            } else if(select == 3){
                System.out.println("====================================");
                System.out.println("커피를 선택했습니다.");
            } else if (select == 4) {
                System.out.println("종료합니다.");

            }

    }


}
