package Vm01;

import java.util.Scanner;

public class VendingMachine01 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int select = 0;
        do {
            String[] product = {"콜라", "사이다", "커피"};
            System.out.println("====================================");
            System.out.println("※ 자판기입니다. 번호를 선택하세요.");
            System.out.println("1:" + product[0] + "   2:" + product[1] + "  3:" + product[2] + "    4:종료");
            select = sc.nextInt();
                switch (select) {
                    case 1:
                        System.out.println("====================================");
                        System.out.println(product[0] + "를 선택했습니다.");
                        break;
                    case 2:
                        System.out.println("====================================");
                        System.out.println(product[1] + "를 선택했습니다.");
                        break;
                    case 3:
                        System.out.println("====================================");
                        System.out.println(product[2] + "를 선택했습니다.");
                        break;
                    case 4:
                        System.out.println("종료합니다.");
                        break;
                } }while (select != 4) ;
            }
        }

