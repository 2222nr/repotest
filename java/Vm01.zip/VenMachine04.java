package Vm01;

public class VenMachine04 {
    public static void main(String[] args) {
        VenMachine03 venMachine03 = new VenMachine03();
        venMachine03.serve();
    }
}
