package Vm01;

import java.util.Scanner;

import static Vm01.VenMachine00.product;
import static Vm01.VenMachine00.select;

public class VenMachine01 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        VenMachine00 venMachine00 = new VenMachine00();

        do {
            System.out.println("====================================");
            System.out.println("※ 자판기입니다. 번호를 선택하세요.");
            System.out.println("1:" + product[0] + "   2:" + product[1] + "  3:" + product[2] + "    4:종료");
            venMachine00.serve(sc.nextInt());

        } while (select != 4);
        sc.close();
    }
}
