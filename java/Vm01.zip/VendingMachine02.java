package Vm01;

import java.util.Scanner;

public class VendingMachine02 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int select = 0;
        String[] product = {"콜라", "사이다", "커피"};
        System.out.println("====================================");
        System.out.println("※ 자판기입니다. 번호를 선택하세요.");
        System.out.println("1:" + product[0] + "   2:" + product[1]+"  3:" + product[2] + "    4:종료");
        select = sc.nextInt();

        while(select != 4){
            if(select == 1){
                System.out.println("====================================");
                System.out.println("콜라를 선택했습니다.");
                System.out.println("====================================");
                break;
            } else if(select == 2){
                System.out.println("====================================");
                System.out.println("사이다를 선택했습니다.");
                System.out.println("====================================");
            } else if(select == 3){
                System.out.println("====================================");
                System.out.println("커피를 선택했습니다.");
                System.out.println("====================================");
            } else {
                System.out.println("종료합니다.");
                select = 4;
            }
        }


        sc.close();
    }
}
