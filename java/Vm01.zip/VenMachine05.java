package Vm01;
import java.util.Scanner;
public class VenMachine05 {

        static String[] products = {"콜라", "사이다", "커피"};

        public static void main(String[] args) {
            Scanner scanner = new Scanner(System.in);

            while (true) {
                System.out.println("====================================");
                System.out.println("※ 자판기입니다. 번호를 선택하세요.");
                for (int i = 0; i < products.length; i++) {
                    System.out.println((i + 1) + ": " + products[i]);
                }
                System.out.println("0: 종료");
                int choice = scanner.nextInt();

                if (choice >= 1 && choice <= products.length) {
                    System.out.println("====================================");
                    System.out.println(products[choice - 1] + "를 선택했습니다.");
                } else if (choice == 0) {
                    System.out.println("종료합니다.");
                    break;
                } else {
                    System.out.println("잘못된 입력입니다. 다시 시도하세요.");
                }
            }

            scanner.close();
        }
    }

