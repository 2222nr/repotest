package Vm01;

import java.util.Scanner;
public class VenMachine03 {
    static String[] product = {"콜라", "사이다", "커피"};
    static int select;
    Scanner sc = new Scanner(System.in);

    void serve(){
        do {
            System.out.println("====================================");
            System.out.println("※ 자판기입니다. 번호를 선택하세요.");
            System.out.println("1:" + product[0] + "   2:" + product[1] + "  3:" + product[2] + "    4:종료");
            select = sc.nextInt();
            if(select == 1){
            System.out.println("====================================");
            System.out.println(product[0] + "를 선택했습니다.");
            }else if(select == 2){
                System.out.println("====================================");
                System.out.println(product[1] + "를 선택했습니다.");
            } else if(select == 3){
                System.out.println("====================================");
                System.out.println(product[2] + "를 선택했습니다.");
            } else {
                System.out.println("종료합니다.");
                select = 4;
             } } while (select != 4);
        sc.close();
    }
}
