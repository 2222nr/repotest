package ch06.quiz;

import java.util.Arrays;
import java.util.Random;

public class LottoNum2 {
    public static void main(String[] args) {
        Random random = new Random();
        int[] numList = new int[6];
        boolean bl = false;

        while(bl=false){
            int i = 0;
            int lottoNum = random.nextInt(45) + 1;
            numList[i] = lottoNum;
            if (numList[i] == lottoNum){
                bl=true;

            }
        }
        System.out.println(Arrays.toString(numList));
    }
}
