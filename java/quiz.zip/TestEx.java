package ch06.quiz;

import java.util.Calendar;

public class TestEx {
    public static void main(String[] args) {
        Calendar now = Calendar.getInstance();
        int week = now.get(Calendar.DAY_OF_WEEK);
        System.out.println(week);
    }
}
