package ch06.quiz;

import java.util.Random;
import java.util.Arrays;

public class LottoNum {
    public static void main(String[] args) {
        Random random = new Random();
        int[] numList = new int[6];

        for(int i=0; i<numList.length; i++){
            int lottoNum = random.nextInt(45) + 1;
            numList[i] = lottoNum;
            for (int j=0; i<j; j++){
                if (numList[i] == numList[j]) {
                    i--;
                    break;
                }
            }
        }
        System.out.println(Arrays.toString(numList));
    }
}
