package ch06.quiz;
import java.util.Scanner;

public class rrnTest1 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int[] intJumin = new int[13];
        String[] strJumin = new String[13];
        int total = 0;

        System.out.print("주민등록번호를 입력하세요(\"-\" 제외) : ");
        String jumin = sc.next();
        strJumin = jumin.split("");
        for(int i=0; i<intJumin.length; i++){
            intJumin[i] = Integer.parseInt(strJumin[i]); }

        for(int i = 0; i < intJumin.length-1; i++){
            if(i <= 7){
                total = total + (intJumin[i] * (i+2));
            } else if (i > 7){
                total = total + (intJumin[i] * (i-6));
            }
        }
        // System.out.println("1단계 값 : " + total);
        total = total % 11;
        // System.out.println("2단계 값 : " + total);
        total = 11 - total;
        // System.out.println("3단계 값 : " + total);
        total = total % 10;
        // System.out.println("4단계 값 : " + total);
        if (total == intJumin[intJumin.length-1]) {
            System.out.println("검증결과 : 올바른 주민번호입니다.");
        } else {
            System.out.println("검증결과 : 잘못된 주민번호입니다.");
        }

        sc.close();
        }
    }

