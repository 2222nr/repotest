package ch06.quiz;
import java.util.Arrays;

public class rrnTest {
    public static void main(String[] args) {
        int[] rrn = {1,4,0,4,1,6,4,1,4,0,8,1,7};
        // int[] one = {2,3,4,5,6,7,8,9,2,3,4,5};
        int[] sum = new int[12];
        // int j = 0;
        int total = 0;

        for(int i = 0; i <= rrn.length; i++){
            if(i <= 7){
            sum[i] = rrn[i] * (i+2);
            } else if (i > 7){
                sum[i] = rrn[i] * (i-6);
            } // else if(i > 12) { break;}
            total += sum[i];
            System.out.println(Arrays.toString(sum));

        }
        System.out.println(total);
        total = total % 11;
        System.out.println(total);
        total = 11 - total;
        System.out.println(total);
        total = total % 10;
        System.out.println(total);
        if (total == rrn[12]) {
            System.out.println("올바른 주민번호입니다.");
        } else {
            System.out.println("잘못된 주민번호입니다.");
        }

    }
}
