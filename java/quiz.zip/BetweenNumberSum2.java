package ch06.quiz;

import java.util.Scanner;

public class BetweenNumberSum2 {
    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);
        String ans = null;
        do {
            System.out.println("--------------------------------");
            int sum = 0;
            System.out.print("첫 번째 수를 입력하세요 : ");
            int num1 = sc.nextInt();
            System.out.print("두 번째 수를 입력하세요 : ");
            int num2 = sc.nextInt();
            if(num1 < num2) {
                for (int i = num1; i <= num2; i++) {
                    sum += i;
                }
            }else if(num1 > num2) {
                for (int i = num2; i <= num1; i++) {
                    sum += i;
                }
            }
            System.out.println("두 수 "+num1+"과 "+num2+ "사이의 수의 합은 : " + sum + "입니다.");
            System.out.print("계속하시겠습니까?(Y/N) : ");
            ans = sc.next();
        } while(ans.equals("Y"));




        sc.close();
    }
}
