package ch06.quiz;

import java.util.Scanner;

public class BetweenNumberSum {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int num1 = 0;
        int num2 = 0;
        int temp;
        int sum;
        String ans = null;

        do {
            System.out.println("--------------------------------");
            sum = 0;
            System.out.print("첫 번째 수를 입력하세요 : ");
            num1 = sc.nextInt();
            System.out.print("두 번째 수를 입력하세요 : ");
            num2 = sc.nextInt();

            if (num1>num2){
                temp = num1; num1 = num2; num2 = temp;
            }

            for (int i = num1; i <= num2; i++) {
                sum += i;
            }

            System.out.println("두 수 "+num1+"과 "+num2+ "사이의 수의 합은 : " + sum + "입니다.");
            System.out.print("계속하시겠습니까?(Y/N) : ");
            ans = sc.next();
        } while(ans.equals("Y"));




        sc.close();
    }
}
